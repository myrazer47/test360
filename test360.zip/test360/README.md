# test360 (scaffold)

این یک اسکلت اولیه برای پروژه test360 است — شامل Node.js سرور و فرانت‌اند preview با امکان نمایش WebUSB.

## شامل چه چیزهایی می‌شود
- `server.js` : سرور Express با مسیرهای پایه‌ی auth و admin (استاب/محلی)
- `public/` : فرانت‌اند ساده (index.html + client.js)
- `data/db.json` : فایل محلی برای نگهداری کاربران/لاگ‌ها (ایجاد خودکار توسط سرور)
- `.env.example` : نمونه متغیرهای محیطی

## راه‌اندازی محلی
1. کلون یا دانلود ریپو:
```bash
git clone https://github.com/myrazer47/test360.git
cd test360
