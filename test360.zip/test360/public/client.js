// client.js - simple UI actions + WebUSB demo + auth calls
async function connectDevice() {
  const info = document.getElementById('deviceInfo');
  try {
    // filter example (Google vendor id). Adapt to your target devices if needed.
    const filters = [{ vendorId: 0x18d1 }];
    const device = await navigator.usb.requestDevice({ filters });
    await device.open();
    info.textContent = 'Connected: ' + device.productName + '\\n' + JSON.stringify({
      productName: device.productName,
      manufacturerName: device.manufacturerName,
      serialNumber: device.serialNumber
    }, null, 2);

    // demo: populate apps list with sample data
    const apps = [
      'com.example.app1 — Example App',
      'com.android.settings — Settings',
      'com.google.android.gms — Google Play Services'
    ];
    document.getElementById('appsList').innerHTML = apps.map(a => '<li>' + a + '</li>').join('');
    // send a log to server
    fetch('/api/log', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({type:'connect', device:device.productName})});
  } catch (e) {
    info.textContent = 'Could not connect: ' + (e && e.message ? e.message : e);
  }
}

document.getElementById('connectBtn').addEventListener('click', connectDevice);

// Register
document.getElementById('regBtn').addEventListener('click', async () => {
  const name = document.getElementById('reg_name').value;
  const phone = document.getElementById('reg_phone').value;
  const email = document.getElementById('reg_email').value;
  const password = document.getElementById('reg_pass').value;
  const res = await fetch('/api/auth/register', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,phone,email,password})});
  const j = await res.json();
  alert(JSON.stringify(j));
});

// Login
document.getElementById('loginBtn').addEventListener('click', async () => {
  const id = document.getElementById('login_identifier').value;
  const pass = document.getElementById('login_pass').value;
  const res = await fetch('/api/auth/login', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({phoneOrEmail:id,password:pass})});
  const j = await res.json();
  document.getElementById('authResult').textContent = JSON.stringify(j, null, 2);
  if (j.ok && j.token) {
    // store demo token
    localStorage.setItem('test360_token', j.token);
  }
});

// Admin fetch
document.getElementById('adminFetch').addEventListener('click', async () => {
  const secret = document.getElementById('admin_secret').value;
  const res = await fetch('/api/admin/stats', { headers: { 'x-admin-secret': secret }});
  const j = await res.json();
  document.getElementById('adminStats').textContent = JSON.stringify(j, null, 2);
});

// navigation
document.getElementById('nav-connect').addEventListener('click', e => {
  e.preventDefault();
  showSection('connectSection');
});
document.getElementById('nav-auth').addEventListener('click', e => {
  e.preventDefault();
  showSection('authSection');
});
document.getElementById('nav-admin').addEventListener('click', e => {
  e.preventDefault();
  showSection('adminSection');
});
function showSection(id) {
  ['connectSection','authSection','adminSection'].forEach(s => {
    document.getElementById(s).style.display = (s === id) ? 'block' : 'none';
  });
}
