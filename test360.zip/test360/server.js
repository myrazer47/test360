// server.js
// Simple Express server + file-based JSON "DB" for scaffolding purposes.

const express = require('express');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const bodyParser = require('body-parser');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_SECRET = process.env.ADMIN_PASSWORD || 'Ramin1372@';

app.use(bodyParser.json());
app.use(require('cors')());
app.use(require('cookie-parser')());

// data folder + db file
const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

function ensureDb() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(DB_FILE)) {
    const initial = { users: [], logs: [] };
    fs.writeFileSync(DB_FILE, JSON.stringify(initial, null, 2), 'utf8');
  }
}
function readDb() {
  ensureDb();
  return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
}
function writeDb(db) {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf8');
}

function hashPassword(p) {
  return crypto.createHash('sha256').update(p || '').digest('hex');
}
function makeToken() {
  return crypto.randomBytes(24).toString('hex');
}

// Serve static frontend
app.use(express.static(path.join(__dirname, 'public')));

// Health
app.get('/health', (req, res) => res.json({ ok: true, time: new Date() }));

// Register
app.post('/api/auth/register', (req, res) => {
  const { name, phone, email, password } = req.body || {};
  if (!phone) return res.status(400).json({ ok: false, message: 'phone required' });

  const db = readDb();
  if (db.users.find(u => u.phone === phone || (email && u.email === email))) {
    return res.status(400).json({ ok: false, message: 'User already exists' });
  }
  const user = {
    id: crypto.randomUUID ? crypto.randomUUID() : crypto.randomBytes(8).toString('hex'),
    name: name || '',
    phone,
    email: email || '',
    passwordHash: hashPassword(password || ''),
    createdAt: new Date().toISOString()
  };
  db.users.push(user);
  writeDb(db);
  res.json({ ok: true, userId: user.id });
});

// Login
app.post('/api/auth/login', (req, res) => {
  const { phoneOrEmail, password } = req.body || {};
  const db = readDb();
  const pHash = hashPassword(password || '');
  const user = db.users.find(u => (u.phone === phoneOrEmail || u.email === phoneOrEmail) && u.passwordHash === pHash);
  if (!user) return res.status(401).json({ ok: false, message: 'Invalid credentials' });

  // simple token (demo). Replace with JWT in production.
  const token = makeToken();
  // add log
  db.logs.push({ type: 'login', userId: user.id, at: new Date().toISOString() });
  writeDb(db);

  res.json({ ok: true, token, user: { id: user.id, name: user.name, phone: user.phone, email: user.email } });
});

// Admin stats (protected by header x-admin-secret or Authorization Bearer)
function isAdmin(req) {
  const header = req.headers['x-admin-secret'] || (req.headers['authorization'] || '').replace(/^Bearer\s*/i, '');
  return header && header === ADMIN_SECRET;
}

app.get('/api/admin/stats', (req, res) => {
  if (!isAdmin(req)) return res.status(403).json({ ok: false, message: 'Forbidden' });
  const db = readDb();
  const users = db.users.length;
  const loginsToday = db.logs.filter(l => l.type === 'login').length;
  const activeNow = 0; // placeholder
  res.json({ ok: true, users, loginsToday, activeNow });
});

app.get('/api/admin/users', (req, res) => {
  if (!isAdmin(req)) return res.status(403).json({ ok: false, message: 'Forbidden' });
  const db = readDb();
  // do not return passwordHash
  const users = db.users.map(u => ({ id: u.id, name: u.name, phone: u.phone, email: u.email, createdAt: u.createdAt }));
  res.json({ ok: true, users });
});

// Logging events from client (e.g., connect/disconnect/actions)
app.post('/api/log', (req, res) => {
  const db = readDb();
  const ev = req.body || {};
  ev.at = new Date().toISOString();
  db.logs.push(ev);
  writeDb(db);
  res.json({ ok: true });
});

// Catch-all serve index.html for SPA routing
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => console.log(`Test360 server listening on ${PORT}`));
